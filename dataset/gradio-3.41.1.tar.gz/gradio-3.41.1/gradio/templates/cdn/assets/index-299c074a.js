import{M as p,S as d}from"./StaticMarkdown-8ed91cc1.js";import"./index-35d55c84.js";import"./utils-c3e3db58.js";import"./Button-9173e03b.js";export{p as MarkdownCode,d as default};
//# sourceMappingURL=index-299c074a.js.map
