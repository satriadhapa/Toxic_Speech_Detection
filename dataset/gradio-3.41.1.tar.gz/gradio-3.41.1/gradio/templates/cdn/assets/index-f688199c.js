import{S as e,e as s,s as a}from"./index-35d55c84.js";class n extends e{constructor(t){super(),s(this,t,null,null,a,{})}}const r=n;export{r as default};
//# sourceMappingURL=index-f688199c.js.map
