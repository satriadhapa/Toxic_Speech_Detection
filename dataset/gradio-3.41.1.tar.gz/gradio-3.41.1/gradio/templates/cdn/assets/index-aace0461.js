import{S as a}from"./StaticColumn-7efb451d.js";import"./index-35d55c84.js";export{a as default};
//# sourceMappingURL=index-aace0461.js.map
