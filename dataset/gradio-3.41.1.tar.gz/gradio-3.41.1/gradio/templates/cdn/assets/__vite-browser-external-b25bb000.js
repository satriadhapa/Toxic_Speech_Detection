const e={};export{e as default};
//# sourceMappingURL=__vite-browser-external-b25bb000.js.map
