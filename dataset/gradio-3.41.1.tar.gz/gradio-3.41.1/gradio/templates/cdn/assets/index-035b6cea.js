import{S as a}from"./StaticForm-30bb7704.js";import"./index-35d55c84.js";export{a as default};
//# sourceMappingURL=index-035b6cea.js.map
