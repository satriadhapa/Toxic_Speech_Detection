import{T as t,S as e}from"./StaticTabs-cea3288c.js";import"./index-35d55c84.js";export{t as TABS,e as default};
//# sourceMappingURL=index-cfc85deb.js.map
