import{aw as o}from"./index-35d55c84.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color-f74abe07.js.map
