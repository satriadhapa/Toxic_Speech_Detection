import{S as e,e as s,s as a}from"./index-1d5c214d.js";class n extends e{constructor(t){super(),s(this,t,null,null,a,{})}}const r=n;export{r as default};
//# sourceMappingURL=index-743acdfc.js.map
