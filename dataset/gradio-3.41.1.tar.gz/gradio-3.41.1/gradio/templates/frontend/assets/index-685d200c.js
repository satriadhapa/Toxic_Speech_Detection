import{S as a}from"./StaticColumn-53374fbf.js";import"./index-1d5c214d.js";export{a as default};
//# sourceMappingURL=index-685d200c.js.map
