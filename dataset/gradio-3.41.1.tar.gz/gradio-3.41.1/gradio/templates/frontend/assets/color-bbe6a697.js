import{aw as o}from"./index-1d5c214d.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color-bbe6a697.js.map
