import{T as t,S as e}from"./StaticTabs-c8eb74d6.js";import"./index-1d5c214d.js";export{t as TABS,e as default};
//# sourceMappingURL=index-71771f6e.js.map
