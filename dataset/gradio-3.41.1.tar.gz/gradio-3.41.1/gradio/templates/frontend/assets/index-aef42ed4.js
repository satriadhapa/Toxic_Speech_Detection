import{M as p,S as d}from"./StaticMarkdown-d6b7db85.js";import"./index-1d5c214d.js";import"./utils-c3e3db58.js";import"./Button-4c5644a6.js";export{p as MarkdownCode,d as default};
//# sourceMappingURL=index-aef42ed4.js.map
