import{S as a}from"./StaticForm-d73a1b4c.js";import"./index-1d5c214d.js";export{a as default};
//# sourceMappingURL=index-278811e4.js.map
