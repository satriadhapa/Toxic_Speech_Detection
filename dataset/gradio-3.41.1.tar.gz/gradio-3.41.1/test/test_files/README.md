Files in this directory are used in:

- tests for the gradio library
- example inputs in the view API documentation

Warning: please be careful when renaming / deleting files
